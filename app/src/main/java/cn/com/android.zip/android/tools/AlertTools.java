package cn.com.android.tools;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class AlertTools {
    public static void alertDialog(Context pContext, int pMessageID, int pButtonTextID) {
        new AlertDialog.Builder(pContext).setMessage(pContext.getString(pMessageID)).setPositiveButton(pButtonTextID, (DialogInterface.OnClickListener) null).show();
    }
}
