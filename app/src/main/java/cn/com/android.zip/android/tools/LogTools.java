package cn.com.android.tools;

import android.util.Log;

public class LogTools {
    public static final String TAG = "********TAG*********";

    public static void printInfo(String pTag, String pMessage) {
        if (pTag == null) {
            Log.i(TAG, pMessage);
        } else {
            Log.i(pTag, pMessage);
        }
    }
}
