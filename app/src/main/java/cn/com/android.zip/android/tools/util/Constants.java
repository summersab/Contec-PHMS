package cn.com.android.tools.util;

public class Constants {
    public static final int BEGIN_DOWNLOAD = 1;
    public static final String TAG = "anroid.self.tools.debug";
    public static final int WAIT_DOWNLOAD_PROGRESS = 0;
}
