package cn.com.android.tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
//import com.alibaba.cchannel.CloudChannelConstants;
import com.nostra13.universalimageloader.core.download.BaseImageDownloader;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import org.apache.commons.httpclient.cookie.CookieSpec;
import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import cn.com.android.tools.util.Constants;

public class NetTools {
    private static int newVerCode;

    public static boolean checkNetCanUse(Context pContext) {
        NetworkInfo _netWrokInfo = ((ConnectivityManager) pContext.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (_netWrokInfo == null || !_netWrokInfo.isAvailable()) {
            return false;
        }
        return true;
    }

    public static boolean checkNewVersion(Context pContext, String pServerAddress, String pAppPackageName) {
        if (!getServerVerCode(pServerAddress) || newVerCode <= getVerCode(pContext, pAppPackageName)) {
            return false;
        }
        return true;
    }

    public static int getVerCode(Context pContext, String pAppPackageName) {
        try {
            return pContext.getPackageManager().getPackageInfo(pAppPackageName, 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            return -1;
        }
    }

    public static boolean getServerVerCode(String pServiceAddress) {
        try {
            JSONArray array = new JSONArray(getVerJsonContent(String.valueOf(pServiceAddress) + "ver.json"));
            if (array.length() > 0) {
                try {
                    newVerCode = Integer.parseInt(array.getJSONObject(0).getString("verCode"));
                } catch (Exception e) {
                    newVerCode = -1;
                    return false;
                }
            }
            return true;
        } catch (Exception e2) {
            Log.e(Constants.TAG, e2.getMessage());
            return false;
        }
    }

    private static String getVerJsonContent(String pUrl) throws Exception {
        StringBuilder sb = new StringBuilder();
        HttpClient client = new DefaultHttpClient();
        HttpParams httpParams = client.getParams();
        HttpConnectionParams.setConnectionTimeout(httpParams, 3000);
        HttpConnectionParams.setSoTimeout(httpParams, BaseImageDownloader.DEFAULT_HTTP_CONNECT_TIMEOUT);
        HttpEntity entity = client.execute(new HttpGet(pUrl)).getEntity();
        if (entity != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(entity.getContent(), "UTF-8"), 8192);
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                sb.append(String.valueOf(line) + "\n");
            }
            reader.close();
        }
        return sb.toString();
    }

    public static void doNewVersionUpdate(Activity pContext, String pAlertUpdateMessage, String pUpdateButtonText, String pNoUpdateButtonText, String pDownLoadFilePath, Handler pHandler, String pUpdateApkSaveName, ProgressDialog pProgressDialog) throws Exception {
        final Activity activity = pContext;
        final String str = pDownLoadFilePath;
        final String str2 = pUpdateApkSaveName;
        final Handler handler = pHandler;
        final ProgressDialog progressDialog = pProgressDialog;
        new AlertDialog.Builder(pContext).setMessage(pAlertUpdateMessage).setPositiveButton(pUpdateButtonText, new DialogInterface.OnClickListener() {
            int size = 0;

            public void onClick(DialogInterface dialog, int which) {
                try {
                    activity.showDialog(0);
                    down(str);
                } catch (Exception e) {
                    Log.i(Constants.TAG, e.toString());
                    e.printStackTrace();
                }
            }

            void down(String pUrl) throws Exception {
                activity.showDialog(1);
                URL url = new URL(pUrl);
                this.size = getDateSize(pUrl);
                int block = (this.size / 1) + 1;
                File file = new File(Environment.getExternalStorageDirectory() + CookieSpec.PATH_DELIM + str2);
                RandomAccessFile rfile = new RandomAccessFile(file, "rw");
                rfile.setLength((long) this.size);
                rfile.close();
                for (int i = 0; i < 1; i++) {
                    int startPosition = i * block;
                    RandomAccessFile threadfile = new RandomAccessFile(file, "rw");
                    threadfile.seek((long) startPosition);
                    NetTools netTools = new NetTools();
                    netTools.getClass();
                    //new DownLoadThread(activity, url, startPosition, threadfile, block, handler, progressDialog, str2, this.size).start();
                }
            }

            private int getDateSize(String pUrl) throws Exception {
                HttpURLConnection con = (HttpURLConnection) new URL(pUrl).openConnection();
                con.setRequestMethod("GET");
                int size2 = con.getContentLength();
                con.disconnect();
                return size2;
            }
        }).setNegativeButton(pNoUpdateButtonText, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                Log.i(Constants.TAG, "cancal upload");
            }
        }).create().show();
    }

    class DownLoadThread extends Thread {
        private int block;
        private Activity mContext;
        private Handler mHandler;
        private ProgressDialog mProgressDialog;
        private int mSize;
        private String mUpdateApkSaveName;
        private int readFileSize;
        private int startPosition;
        private RandomAccessFile threadfile;
        private URL url;

        public void run() {
            int len;
            boolean z = true;
            try {
                super.run();
                this.mContext.dismissDialog(0);
                HttpURLConnection con = (HttpURLConnection) this.url.openConnection();
                con.setRequestMethod("GET");
                con.setRequestProperty("Range", "bytes=" + this.startPosition + "-");
                //con.setConnectTimeout(CloudChannelConstants.WEBVIEW_PROXY_HTTP_TIMEOUT);
                PrintStream printStream = System.out;
                if (con.getResponseCode() != 206) {
                    z = false;
                }
                printStream.print(z);
                if (con.getResponseCode() == 206) {
                    InputStream inputStream = con.getInputStream();
                    byte[] buffer = new byte[1024];
                    this.readFileSize = 0;
                    while (this.readFileSize < this.block && (len = inputStream.read(buffer)) != -1) {
                        this.threadfile.write(buffer, 0, len);
                        this.readFileSize += len;
                        Message msg = new Message();
                        msg.what = 1;
                        msg.arg1 = this.readFileSize;
                        msg.arg2 = this.mSize;
                        this.mProgressDialog.setProgress(msg.arg1);
                        this.mProgressDialog.setMax(msg.arg2);
                        this.mHandler.sendMessage(msg);
                    }
                    sleep(3000);
                    this.threadfile.close();
                    con.disconnect();
                    System.out.println("-----------------------over" + this.readFileSize);
                    if (this.mSize == this.readFileSize && this.mContext != null && !this.mContext.isFinishing()) {
                        this.mProgressDialog.dismiss();
                        update(this.mContext);
                    }
                }
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e2) {
                e2.printStackTrace();
            } catch (InterruptedException e3) {
                e3.printStackTrace();
            }
        }

        void update(Activity pContext) {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setDataAndType(Uri.fromFile(new File(Environment.getExternalStorageDirectory(), this.mUpdateApkSaveName)), "application/vnd.android.package-archive");
            pContext.startActivity(intent);
        }

        public DownLoadThread(Activity pContext, URL url2, int startPosition2, RandomAccessFile threadfile2, int block2, Handler pHandler, ProgressDialog pProgressDialog, String pUpdateApkSaveName, int pSize) {
            this.url = url2;
            this.startPosition = startPosition2;
            this.threadfile = threadfile2;
            this.block = block2;
            this.mContext = pContext;
            this.mHandler = pHandler;
            this.mProgressDialog = pProgressDialog;
            this.mUpdateApkSaveName = pUpdateApkSaveName;
            this.mSize = pSize;
        }
    }
}
